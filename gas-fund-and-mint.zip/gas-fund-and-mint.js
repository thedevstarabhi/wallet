// gas-fund-and-mint.js
// One-file demo: deploy ERC20, create child wallet, fund it with native gas from parent,
// then mint tokens from the child via the contract's mint().
//
// Prereqs: `npm i`
// Env: RPC_URL, PARENT_PK
// Optional env: TOKEN_NAME, TOKEN_SYMBOL, FUND_ETH, MINT_TO, MINT_AMOUNT

import { ethers } from "ethers";
import solc from "solc";

// ---------- Config from ENV ----------
const RPC_URL     = process.env.RPC_URL;
const PARENT_PK   = process.env.PARENT_PK;

const TOKEN_NAME  = process.env.TOKEN_NAME  || "TestToken";
const TOKEN_SYMBOL= process.env.TOKEN_SYMBOL|| "TT";
const FUND_ETH    = process.env.FUND_ETH    || "0.003"; // native sent to child
const MINT_TO_ENV = process.env.MINT_TO     || "";      // if empty, mint to child
const MINT_AMOUNT = process.env.MINT_AMOUNT || "100";   // whole tokens (18 decimals)

// ---------- Solidity source (minimal ERC-20 with owner-only mint) ----------
const source = `
pragma solidity ^0.8.20;

contract SimpleMintableERC20 {
    string public name;
    string public symbol;
    uint8 public decimals = 18;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    address public owner;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed o, address indexed s, uint256 value);

    constructor(string memory _name, string memory _symbol) {
        name = _name;
        symbol = _symbol;
        owner = msg.sender;
    }

    function transfer(address to, uint256 value) public returns (bool) {
        require(balanceOf[msg.sender] >= value, "bal");
        unchecked { balanceOf[msg.sender] -= value; balanceOf[to] += value; }
        emit Transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) public returns (bool) {
        allowance[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) public returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= value, "allow");
        require(balanceOf[from] >= value, "bal");
        if (allowed != type(uint256).max) {
            allowance[from][msg.sender] = allowed - value;
        }
        unchecked { balanceOf[from] -= value; balanceOf[to] += value; }
        emit Transfer(from, to, value);
        return true;
    }

    function mint(address to, uint256 value) public {
        require(msg.sender == owner, "only owner");
        totalSupply += value;
        balanceOf[to] += value;
        emit Transfer(address(0), to, value);
    }

    function setOwner(address newOwner) public {
        require(msg.sender == owner, "only owner");
        owner = newOwner;
    }
}
`;

// ---------- Compile with solc ----------
function compile(source) {
  const input = {
    language: "Solidity",
    sources: { "SimpleMintableERC20.sol": { content: source } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } }
    }
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  if (output.errors) {
    const errs = output.errors.filter(e => e.severity === "error");
    if (errs.length) {
      throw new Error("Solc errors:\n" + errs.map(e => e.formattedMessage).join("\n"));
    }
  }
  const contract = output.contracts["SimpleMintableERC20.sol"]["SimpleMintableERC20"];
  return { abi: contract.abi, bytecode: "0x" + contract.evm.bytecode.object };
}

async function main() {
  if (!RPC_URL || !PARENT_PK) {
    console.error("Set RPC_URL and PARENT_PK env vars (.env).");
    process.exit(1);
  }

  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const parent = new ethers.Wallet(PARENT_PK, provider);

  console.log("Parent:", parent.address);
  const parentBalStart = await provider.getBalance(parent.address);
  console.log("Parent balance:", ethers.formatEther(parentBalStart), "native");

  // 1) Compile + Deploy ERC20 from parent
  console.log("\nCompiling & deploying SimpleMintableERC20...");
  const { abi, bytecode } = compile(source);
  const factory = new ethers.ContractFactory(abi, bytecode, parent);
  const contract = await factory.deploy(TOKEN_NAME, TOKEN_SYMBOL);
  const deployRcpt = await contract.waitForDeployment();
  const tokenAddress = await contract.getAddress();
  console.log("Token deployed at:", tokenAddress, "tx:", deployRcpt.deploymentTransaction().hash);

  // 2) Create a fresh child wallet (in-memory) + connect to provider
  const child = ethers.Wallet.createRandom().connect(provider);
  console.log("\nChild wallet:", child.address);

  // 3) Fund child with native ETH/SEI for gas
  const fundValue = ethers.parseEther(FUND_ETH);
  console.log(`Funding child with ${FUND_ETH} native...`);
  const fundTx = await parent.sendTransaction({ to: child.address, value: fundValue });
  await fundTx.wait();
  const childBal = await provider.getBalance(child.address);
  console.log("Child balance:", ethers.formatEther(childBal), "native");

  // 4) Hand over contract owner to child so it can call mint()
  console.log("\nTransferring token owner to child...");
  const asParent = new ethers.Contract(tokenAddress, abi, parent);
  const setOwnerTx = await asParent.setOwner(child.address);
  await setOwnerTx.wait();
  console.log("Owner set ->", child.address);

  // 5) Mint from child
  const asChild = new ethers.Contract(tokenAddress, abi, child);
  const toMintAddress = MINT_TO_ENV || child.address;
  const amountWei = ethers.parseUnits(MINT_AMOUNT, 18n); // 18 decimals
  console.log(`\nMinting ${MINT_AMOUNT} ${TOKEN_SYMBOL} to ${toMintAddress} from child...`);
  const mintTx = await asChild.mint(toMintAddress, amountWei);
  const mintRcpt = await mintTx.wait();
  console.log("Mint tx:", mintRcpt.hash);

  // 6) Show balances
  const childTokenBal = await asChild.balanceOf(child.address);
  const toMintBal = await asChild.balanceOf(toMintAddress);
  const totalSupply = await asChild.totalSupply();
  console.log("\n=== Final State ===");
  console.log("Token:", tokenAddress);
  console.log("Total supply:", ethers.formatUnits(totalSupply, 18));
  console.log("Child token balance:", ethers.formatUnits(childTokenBal, 18));
  console.log(`${toMintAddress === child.address ? "Child" : "Mint-to"} balance:`, ethers.formatUnits(toMintBal, 18));

  const parentBalEnd = await provider.getBalance(parent.address);
  console.log("\nParent balance (end):", ethers.formatEther(parentBalEnd), "native");
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
